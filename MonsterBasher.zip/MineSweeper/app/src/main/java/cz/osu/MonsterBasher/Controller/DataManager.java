package cz.osu.MonsterBasher.Controller;

import android.content.Intent;
import android.os.Bundle;

import java.util.ArrayList;

public class DataManager {
    private Intent intentSettings;
    private Intent intentCreateChar;
    private int score;
    private ArrayList<String> myScores;
    private boolean allowSaving = false;

    public DataManager(){
        myScores = new ArrayList<>();
    }

    private static final DataManager dataHOld = new DataManager();

    public static DataManager getDataMan(){
        return dataHOld;
    }
                                                /*Settings*/
    public Intent getIntentSettings(Intent intent){
        if(intentSettings != null){
            return intentSettings;
        }
        else {
            setIntentSettings(intent);
            return intentSettings;
        }

    }

    public void setIntentSettings(Intent intent){
        intentSettings = intent;
    }
    public void setSettings(String key, int value){
        intentSettings.putExtra(key, value);
    }
    public void setSettings(String key, boolean dev){
        intentSettings.putExtra(key, dev);
    }

    public int getSettingsDiff(String key){
        if(intentSettings != null && intentSettings.getExtras() != null){
            Bundle ret = intentSettings.getExtras();
            return  ret.getInt(key);
        }
        else{
            return 1;
        }

    }
    public boolean getSettingsDev(String key){
        if(intentSettings != null && intentSettings.getExtras() != null){
            Bundle ret = intentSettings.getExtras();
            return ret.getBoolean(key);
        }
        else {
            return false;
        }
    }
                                            /*Create character*/

    public void setIntentCreateChar(Intent intent){
        intentCreateChar = intent;
    }

    public Intent getIntentCreateChar(Intent intent){
        if(intentCreateChar != null){
            return intentCreateChar;
        }
        else {
            setIntentCreateChar(intent);
            return intentCreateChar;
        }
    }

    public void setHeroName(String key, String value){
        if(value.equals("")){
            intentCreateChar.putExtra(key,"Nameless Hero");
        }
        else {
            intentCreateChar.putExtra(key,value);
        }

    }

    public String getHeroName(String key){
        Bundle ret = intentCreateChar.getExtras();
        if(ret == null){
            return "Nameless Hero";
        }else if(ret.getString(key).equals("")){
            return "Nameless Hero";
        }
        else {
            return  ret.getString(key);
        }
    }
    /*SCORES*/
    public void setScore(){
        score++;
    }

    public int getScore(){
        return score;
    }

    public void resetScore(){
        score = 0;
    }

    public ArrayList<String> getMyScores() {
        return myScores;
    }

    /*Saving*/

    public boolean isAllowSaving() {
        return allowSaving;
    }

    public void setAllowSaving(boolean allowSaving) {
        this.allowSaving = allowSaving;
    }
}

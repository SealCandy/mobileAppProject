package cz.osu.MonsterBasher.View;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import cz.osu.minesweeper.R;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void onClickStart(View view){
        Intent intent = new Intent(this, NewCharacter.class);
        startActivity(intent);
        finish();
    }
    public void onClickOptions(View view){
        Intent intent = new Intent(this,Options.class);
        startActivity(intent);
        finish();
    }
    public void onClickScore(View view){
        Intent intent = new Intent(this,Score.class);
        startActivity(intent);
        finish();
    }
}
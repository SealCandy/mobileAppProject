package cz.osu.MonsterBasher.Controller;

import java.util.ArrayList;
import java.util.Random;

import cz.osu.MonsterBasher.Model.Monster;

public class EnemyRandomizer {
    private ArrayList<Monster> monsters;
    private Random random;
    public EnemyRandomizer(int difficulty){
        random = new Random();
        monsters = new ArrayList<>();
        monsters.add(new Monster("Goblin",difficulty));
        monsters.add(new Monster("Banshee",difficulty));
        monsters.add(new Monster("Mollusk",difficulty));
        monsters.add(new Monster("Crab",difficulty));
        monsters.add(new Monster("Big Merchant",difficulty));
        monsters.add(new Monster("ErrorMAn",difficulty));
    }

    public Monster getMonster(){
        int index = random.nextInt(5);
        return monsters.get(index);
    }
}
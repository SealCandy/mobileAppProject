package cz.osu.MonsterBasher.View;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.ArrayList;

import cz.osu.MonsterBasher.Controller.DataManager;
import cz.osu.minesweeper.R;

public class Score extends AppCompatActivity {
    public static String myFile = "myScores.txt";
    private ArrayList<String> myScores;
    private ListView listViewTasks;
    private ArrayAdapter<String> arrayAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_score);
        myScores = DataManager.getDataMan().getMyScores();

        listViewTasks = (ListView) findViewById(R.id.listViewTasks);
        uploadFromFile();
        saveToFile(DataManager.getDataMan().isAllowSaving());
        arrayAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1, myScores);
        listViewTasks.setAdapter(arrayAdapter);
    }

    public void uploadFromFile(){
        try{
            InputStream myInputStream = openFileInput(myFile);
            if (myInputStream != null){
                InputStreamReader myInputStreamReader = new InputStreamReader(myInputStream);
                BufferedReader myBufferedReader = new BufferedReader(myInputStreamReader);
                String line = "";
                StringBuffer myStringBuffer = new StringBuffer();

                myScores.clear();
                while ((line = myBufferedReader.readLine()) != null) {
                    myStringBuffer.append(line);
                    myScores.add(line);
                }
                myInputStream.close();

            }
        }
        catch (Exception e){
            Toast.makeText(this, e.toString(), Toast.LENGTH_LONG).show();
        }
    }

    public void saveToFile(boolean allowSaving){
        if(allowSaving){
            try{
                OutputStream myOtputStream = openFileOutput(myFile, 0);
                OutputStreamWriter myOutputStreamWriter = new OutputStreamWriter(myOtputStream);
                myScores.add(DataManager.getDataMan().getHeroName("hero") +":" + Integer.toString(DataManager.getDataMan().getScore()));

                listViewTasks.setAdapter(arrayAdapter);
                for (int i=0; i<myScores.size(); i++)
                    myOutputStreamWriter.write(myScores.get(i).toString()+"\n");
                myOutputStreamWriter.close();

            }
            catch (Exception e){
                Toast.makeText(this, e.toString(), Toast.LENGTH_LONG).show();
            }
        }
    }


    public void onClickBack(View view){
        DataManager.getDataMan().setAllowSaving(false);
        Intent intent = new Intent(this,MainActivity.class);
        startActivity(intent);
        finish();
    }

    public void onClickWipeData(View view){
        myScores.clear();
        saveToFile(true);
    }

}
package cz.osu.MonsterBasher.Model;

import java.util.Random;

public class Player {
    private int maxHp;
    private int hp;
    private int armor;
    private int damage;
    private int lvl;
    private int xp;
    private String name;

    private Random random;

    public Player(String name, boolean dev){
        random = new Random();
        this.name = name;
        if(!dev){
            hp = random.nextInt(100) + 20;
            maxHp = hp;
            armor = random.nextInt(5);
            damage = random.nextInt(10) + 5;
            xp = 0;
            lvl = 1;
        }
        else {
            hp = 90000;
            maxHp = hp;
            armor = 90000;
            damage = 90000;
            lvl = 99;
            xp = 0;
        }
    }

    public int attack(int enemyHP){
        enemyHP = enemyHP - damage;
        if(enemyHP <= 0){
            enemyHP = 0;
            return enemyHP;
        }
        return enemyHP;
    }

    public void defend(){
        if(hp < maxHp){
            if(hp + 20 >= maxHp){
                hp = maxHp;
            }else {
                hp += 20;
            }
        }
    }

    public void checkLvl(int value){
        xp += value;
        if(xp == 100){
            xp = 0;
            lvl++;
            armor += random.nextInt(5);
            damage += random.nextInt(10);
            maxHp += random.nextInt(20);
            hp = maxHp;
        }else if(xp > 100){
            xp -= 100;
            lvl++;
            armor += random.nextInt(5);
            damage += random.nextInt(10);
            maxHp += random.nextInt(20);
            hp = maxHp;
        }
    }

    public int getMaxHp() {
        return maxHp;
    }

    public int getHp() {
        return hp;
    }

    public void setHp(int hp) {
        if(hp <= 0){
            this.hp = 0;
        }
        else {
            this.hp = hp;
        }
    }

    public int getArmor() {
        return armor;
    }

    public int getDamage() {
        return damage;
    }

    public int getLvl() {
        return lvl;
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}

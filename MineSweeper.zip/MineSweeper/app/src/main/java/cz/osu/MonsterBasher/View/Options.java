package cz.osu.MonsterBasher.View;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import cz.osu.MonsterBasher.Controller.DataManager;
import cz.osu.minesweeper.R;

public class Options extends AppCompatActivity {
private boolean cheats;
private Button btnEasy;
private Button btnNormal;
private Button btnImpossible;
private Button btnDev;
private DataManager dataManager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_options);
        setObjects();
        checkDev(dataManager.getDataMan().getSettingsDev("dev"));
        buttonChecker(dataManager.getDataMan().getSettingsDiff("diff"));

    }
    public void onClickBack(View view){
        Intent intent = new Intent(this,MainActivity.class);
        startActivity(intent);
        finish();
    }

    public void setObjects(){
        btnEasy = (Button) findViewById(R.id.buttonGoBack);
        btnNormal = (Button) findViewById(R.id.buttonCreate);
        btnImpossible = (Button) findViewById(R.id.buttonImpossible);
        btnDev = (Button) findViewById(R.id.buttonCheats);
        dataManager.getDataMan().getIntentSettings(this.getIntent());

    }

    public void onClickEasy(View view){
        buttonChecker(0);
    }

    public void onClickNormal(View view){
        buttonChecker(1);
    }

    public void onClickImpossible(View view){
        buttonChecker(2);
    }

    public void onClickDev(View view){
        if(cheats){
            cheats = false;
            btnDev.setBackground(getResources().getDrawable(R.drawable.button_bg_color_onclick));
            dataManager.getDataMan().setSettings("dev",false);
        }
        else {
            cheats = true;
            btnDev.setBackground(getResources().getDrawable(R.drawable.button_bg_color_active));
            dataManager.getDataMan().setSettings("dev",true);
        }
    }
    public void checkDev(boolean dev){
        if(dev == true){
            cheats = true;
            btnDev.setBackground(getResources().getDrawable(R.drawable.button_bg_color_active));
        }else {
            cheats = false;
            btnDev.setBackground(getResources().getDrawable(R.drawable.button_bg_color_onclick));
        }
    }
    public void buttonChecker(int value){
        switch (value){
            case 0:
                btnEasy.setBackground(getResources().getDrawable(R.drawable.button_bg_color_active));
                btnNormal.setBackground(getResources().getDrawable(R.drawable.button_bg_color_onclick));
                btnImpossible.setBackground(getResources().getDrawable(R.drawable.button_bg_color_onclick));
                dataManager.getDataMan().setSettings("diff",0);
                break;
            case 1:
                btnNormal.setBackground(getResources().getDrawable(R.drawable.button_bg_color_active));
                btnEasy.setBackground(getResources().getDrawable(R.drawable.button_bg_color_onclick));
                btnImpossible.setBackground(getResources().getDrawable(R.drawable.button_bg_color_onclick));
                dataManager.getDataMan().setSettings("diff",1);
                break;
            case 2:
                btnImpossible.setBackground(getResources().getDrawable(R.drawable.button_bg_color_active));
                btnNormal.setBackground(getResources().getDrawable(R.drawable.button_bg_color_onclick));
                btnEasy.setBackground(getResources().getDrawable(R.drawable.button_bg_color_onclick));
                dataManager.getDataMan().setSettings("diff",2);
                break;
        }
    }
}
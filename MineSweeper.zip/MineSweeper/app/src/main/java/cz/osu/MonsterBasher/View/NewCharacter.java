package cz.osu.MonsterBasher.View;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import cz.osu.MonsterBasher.Controller.DataManager;
import cz.osu.MonsterBasher.Model.Player;
import cz.osu.minesweeper.R;

public class NewCharacter extends AppCompatActivity {
private DataManager dataManager;
private TextView name;
private Player player;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        name = (TextView) findViewById(R.id.editTextHeroName);
        dataManager.getDataMan().getIntentCreateChar(this.getIntent());
        setContentView(R.layout.activity_new_character);
    }


    public void onClickBack(View view){
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
        finish();
    }
    public void onClickCreate(View view){
        Intent intent = new Intent(this, MonsterBasher.class);
        dataManager.getDataMan().setHeroName("HeroName",name.getText().toString());
        startActivity(intent);
        finish();
    }
}
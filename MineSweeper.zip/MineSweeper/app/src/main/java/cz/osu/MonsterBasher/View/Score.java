package cz.osu.MonsterBasher.View;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Random;

import cz.osu.MonsterBasher.Controller.DataManager;
import cz.osu.minesweeper.R;

public class Score extends AppCompatActivity {
private TextView[] textViews;
private Random random;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_score);
        setObjects();
        setScore(DataManager.getDataMan().getScore());
    }
    public void onClickBack(View view){
        Intent intent = new Intent(this,MainActivity.class);
        startActivity(intent);
        finish();
    }

    private void setObjects(){
        textViews = new TextView[5];
        textViews[0] = (TextView) findViewById(R.id.textViewScore1);
        textViews[1] = (TextView) findViewById(R.id.textViewScore2);
        textViews[2] = (TextView) findViewById(R.id.textViewScore3);
        textViews[3] = (TextView) findViewById(R.id.textViewScore4);
        textViews[4] = (TextView) findViewById(R.id.textViewScore5);
        random = new Random();
    }
    public void setScore(int score){
        for (int i = 0; i < textViews.length; i++) {
            if(isEmpty(i)){
                textViews[i].setText(DataManager.getDataMan().getHeroName("hero") +":" + Integer.toString(score));
                break;
            }else{
                textViews[random.nextInt(4)].setText(DataManager.getDataMan().getHeroName("hero") +":" + Integer.toString(score));
            }
        }
    }
    public boolean isEmpty(int index){
        if(index == 4){
            return false;
        }
        if(textViews[index].getText().equals(textViews[index+1].getText())){
            return true;
        }
        else{
            return false;
        }
    }
}
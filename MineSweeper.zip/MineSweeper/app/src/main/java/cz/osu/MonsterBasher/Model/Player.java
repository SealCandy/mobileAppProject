package cz.osu.MonsterBasher.Model;

import java.util.Random;

public class Player {
    private int maxHp;
    private int hp;
    private int armor;
    private int damage;
    private int lvl;
    private int xp;
    private String name;

    private Random random;

    public Player(String name){
        this.name = name;
        hp = random.nextInt(100) + 1;
        maxHp = hp;
        armor = random.nextInt(20);
        damage = random.nextInt(10) + 5;
        xp = 0;
        lvl = 1;
    }

    public int attack(int enemyHP, int enemyResistance){
        enemyHP = enemyHP - (damage/enemyResistance);
        return enemyHP;
    }

    public void defend(){
        if(hp < maxHp){
            if(hp + 20 >= maxHp){
                hp = maxHp;
            }else {
                hp += 20;
            }
        }
    }

    public void checkLvl(int value){
        xp += value;
        if(xp == 100){
            xp = 0;
            lvl++;
            armor += random.nextInt(5);
            damage += random.nextInt(10);
            maxHp += random.nextInt(20);
            hp = maxHp;
        }else if(xp > 100){
            xp -= 100;
            lvl++;
            armor += random.nextInt(5);
            damage += random.nextInt(10);
            maxHp += random.nextInt(20);
            hp = maxHp;
        }
    }

    public int getMaxHp() {
        return maxHp;
    }

    public void setMaxHp(int maxHp) {
        this.maxHp = maxHp;
    }

    public int getHp() {
        return hp;
    }

    public void setHp(int hp) {
        this.hp = hp;
    }

    public int getArmor() {
        return armor;
    }

    public void setArmor(int armor) {
        this.armor = armor;
    }

    public int getDamage() {
        return damage;
    }

    public void setDamage(int damage) {
        this.damage = damage;
    }

    public int getLvl() {
        return lvl;
    }

    public void setLvl(int lvl) {
        this.lvl = lvl;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}

package cz.osu.MonsterBasher.View;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import cz.osu.MonsterBasher.Controller.DataManager;
import cz.osu.MonsterBasher.Controller.EnemyRandomizer;
import cz.osu.MonsterBasher.Model.Monster;
import cz.osu.MonsterBasher.Model.Player;
import cz.osu.minesweeper.R;

public class MonsterBasher extends AppCompatActivity {
private DataManager dataManager;
private Player player;
private Monster monster;
private EnemyRandomizer enemyRandomizer;
private TextView enemyName;
private TextView heroHp;
private TextView heroLvl;
private TextView enemyHp;
private TextView enemyLvl;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_monster_basher);
        setObjects();
    }
    public void setObjects(){
        enemyRandomizer = new EnemyRandomizer(dataManager.getDataMan().getSettingsDiff("diff"));
        monster = enemyRandomizer.getMonster();

        String name = dataManager.getDataMan().getHeroName("hero");
        Boolean dev = dataManager.getDataMan().getSettingsDev("dev");

        player = new Player(name, dev);
        TextView heroName = heroName = (TextView) findViewById(R.id.textViewPlayerName);
        heroHp = (TextView) findViewById(R.id.textViewHeroHp);
        heroLvl = (TextView) findViewById(R.id.textViewHeroLvl);
        enemyName = enemyName = (TextView) findViewById(R.id.textViewEnemyName);
        enemyHp = (TextView) findViewById(R.id.textViewEnemyHp);
        enemyLvl = (TextView) findViewById(R.id.textViewEnemyLvl);
        heroName.setText(name);
        heroHp.setText("HP: "+ Integer.toString(player.getHp()));
        heroLvl.setText("Lvl: " + Integer.toString(player.getLvl()));
        enemyName.setText(monster.getName());
        enemyHp.setText("Hp: " + Integer.toString(monster.getHp()));
        enemyLvl.setText("Lvl" +Integer.toString(monster.getLvl()));
    }
    public void onClickAttack(View view){
        if(monster.getHp() == 0){
            dataManager.getDataMan().setScore();
            player.checkLvl(20);
            generateNewMonster();
        }else if(player.getHp() == 0){
            Intent intent = new Intent(this, Score.class);
            startActivity(intent);
            finish();
        }
        monster.setHp(player.attack(monster.getHp()));
        player.setHp(monster.attack(player.getHp(),player.getArmor()));
        reRenderValues();
    }
    public void onClickDefend(View view){
        monster.defend();
        player.defend();
        reRenderValues();
    }

    public void reRenderValues(){
        heroHp.setText("HP: "+ Integer.toString(player.getHp()));
        heroLvl.setText("Lvl: " + Integer.toString(player.getLvl()));
        enemyHp.setText("Hp: " + Integer.toString(monster.getHp()));
        enemyLvl.setText("Lvl" +Integer.toString(monster.getLvl()));
    }

    public void generateNewMonster(){
        monster = enemyRandomizer.getMonster();
        enemyName.setText(monster.getName());
    }
    public void onClickGiveUp(View view){
        Intent intent = new Intent(this, Score.class);
        startActivity(intent);
        finish();
    }
}
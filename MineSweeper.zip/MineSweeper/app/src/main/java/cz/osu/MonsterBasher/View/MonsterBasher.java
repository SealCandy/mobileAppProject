package cz.osu.MonsterBasher.View;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import cz.osu.minesweeper.R;

public class MonsterBasher extends AppCompatActivity {
private TextView heroName;
private TextView heroHp;
private TextView heroLvl;
private TextView enemyName;
private TextView enemyHp;
private TextView enemyLvl;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setObjects();
        setContentView(R.layout.activity_monster_basher);
    }
    public void setObjects(){
        heroName = (TextView) findViewById(R.id.textViewHeroName);
        heroHp = (TextView) findViewById(R.id.textViewHeroHp);
        heroLvl = (TextView) findViewById(R.id.textViewHeroLvl);
        enemyName = (TextView) findViewById(R.id.textViewEnemyName);
        enemyHp = (TextView) findViewById(R.id.textViewEnemyHp);
        enemyLvl = (TextView) findViewById(R.id.textViewEnemyLvl);
    }
    public void onClickAttack(View view){

    }
    public void onClickDefend(View view){

    }
    public void onClickGiveUp(View view){
        Intent intent = new Intent(this, Score.class);
        startActivity(intent);
        finish();
    }
}
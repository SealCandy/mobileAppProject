package cz.osu.MonsterBasher.Controller;

import android.content.Intent;
import android.os.Bundle;

import cz.osu.MonsterBasher.Model.Player;

public class DataManager {
    private Intent intentSettings;
    private Intent intentCreateChar;
    private Intent placeHoles;

    private static final DataManager dataHOld = new DataManager();

    public static DataManager getDataMan(){
        return dataHOld;
    }
                                                /*Settings*/
    public Intent getIntentSettings(Intent intent){
        if(intentSettings != null){
            return intentSettings;
        }
        else {
            setIntentSettings(intent);
            return intentSettings;
        }

    }

    public void setIntentSettings(Intent intent){
        intentSettings = intent;
    }
    public void setSettings(String key, int value){
        intentSettings.putExtra(key, value);
    }
    public void setSettings(String key, boolean dev){
        intentSettings.putExtra(key, dev);
    }

    public int getSettingsDiff(String key){
        Bundle ret = intentSettings.getExtras();
        if(ret == null){
            return 0;
        }
        else {
            return  ret.getInt(key);
        }
    }
    public boolean getSettingsDev(String key){
        Bundle ret = intentSettings.getExtras();
        if(ret == null){
            return false;
        }
        else {
            return  ret.getBoolean(key);
        }
    }
                                            /*Create character*/
    public void setIntentCreateChar(Intent intent){
        intentCreateChar = intent;
    }

    public Intent getIntentCreateChar(Intent intent){
        if(intentCreateChar != null){
            return intentCreateChar;
        }
        else {
            setIntentCreateChar(intent);
            return intentCreateChar;
        }
    }

    public void setHero(String key, Player value){
        intentCreateChar.putExtra(key,value.getArmor());
        intentCreateChar.putExtra(key,value.getDamage());
        intentCreateChar.putExtra(key,value.getHp());
        intentCreateChar.putExtra(key,value.getMaxHp());
        intentCreateChar.putExtra(key,value.getLvl());
        intentCreateChar.putExtra(key,value.getName());
    }

    public String getHeroName(String key){
        Bundle ret = intentCreateChar.getExtras();
        if(ret == null){
            return "Nameless Hero";
        }else if(ret.getString(key).equals("")){
            return "Nameless Hero";
        }
        else {
            return  ret.getString(key);
        }
    }
}

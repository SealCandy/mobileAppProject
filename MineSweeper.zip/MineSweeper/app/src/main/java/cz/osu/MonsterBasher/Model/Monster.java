package cz.osu.MonsterBasher.Model;

public class Monster {
    private int maxHp;
    private int hp;
    private int damage;
    private int level;
    private int resistance;
    private String name;

    public Monster(){

    }

    public int attack(int enemyHP, int armor){
        enemyHP = enemyHP - (damage - armor);
        return enemyHP;
    }

    public void defend(){
        if(hp < maxHp){
            if(hp + 30 >= maxHp){
                hp = maxHp;
            }else {
                hp += 30;
            }
        }
    }

}

package cz.osu.MonsterBasher.Model;

import java.util.Random;

public class Monster {
    private int maxHp;
    private int hp;
    private int damage;
    private int lvl;
    private String name;
    private Random random;
    public Monster(String name, int difficulty){
        random = new Random();
          this.name = name;
        switch (difficulty){
            case 0:
                hp = random.nextInt(5) + 1;
                maxHp = hp;
                damage = random.nextInt(1) + 5;
                lvl = random.nextInt(6);
                break;
            case 1:
                hp = random.nextInt(100) + 35;
                maxHp = hp;
                damage = random.nextInt(10) + 5;
                lvl = random.nextInt(30);
                break;
            case 2:
                hp = random.nextInt(100000) + 1;
                maxHp = hp;
                damage = random.nextInt(1000) + 5;
                lvl = random.nextInt(95) + 20;
                break;
        }
    }

    public int attack(int enemyHP, int armor){
        if(armor > damage){
            return enemyHP;
        }
        else {
            enemyHP =  enemyHP - (damage - armor);
            if(enemyHP <= 0){
                enemyHP = 0;
                return enemyHP;
            }
            return enemyHP;
        }
    }

    public void defend(){
        if(hp < maxHp){
            if(hp + 30 >= maxHp){
                hp = maxHp;
            }else {
                hp += 30;
            }
        }
    }


    public int getHp() {
        return hp;
    }

    public void setHp(int hp) {
        if(hp <= 0){
            this.hp = 0;
        }
        else {
            this.hp = hp;
        }
    }

    public int getDamage() {
        return damage;
    }

    public int getLvl() {
        return lvl;
    }

    public String getName() {
        return name;
    }
}
